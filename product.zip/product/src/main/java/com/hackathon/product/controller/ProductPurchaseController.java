package com.hackathon.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hackathon.product.entities.ProductDetailEntity;
import com.hackathon.product.repository.*;
import com.hackathon.product.requestObjects.UserPurchaseDetailRO;
import com.hackathon.product.service.ProductPurchaseService;


@RestController
public class ProductPurchaseController {
    
    @Autowired
    ProductRepository productRepository;

    @Autowired
    ProductPurchaseService productPurchaseService;

    @GetMapping("/productDetails")
    public List<ProductDetailEntity> getProductDetails()
    {
        
        return productRepository.findAll();
               
    }

    @PostMapping("/userPurchaseDetails")
    public void postUserPurchaseDetails(
        UserPurchaseDetailRO userPurchaseDetailRO
    )
    {
        productPurchaseService.savePurchaseDetails(userPurchaseDetailRO);
    }

}