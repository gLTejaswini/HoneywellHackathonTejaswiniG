package com.hackathon.product.requestObjects;

import java.util.List;

public class UserPurchaseDetailRO {
    
    private UserDetailRO userDetail;

    private List<ProductDetailRO> productDetailROs;

    /**
     * @return UserDetailRO return the userDetail
     */
    public UserDetailRO getUserDetail() {
        return userDetail;
    }

    /**
     * @param userDetail the userDetail to set
     */
    public void setUserDetail(UserDetailRO userDetail) {
        this.userDetail = userDetail;
    }

    /**
     * @return List<ProductDetailRO> return the productDetailROs
     */
    public List<ProductDetailRO> getProductDetailROs() {
        return productDetailROs;
    }

    /**
     * @param productDetailROs the productDetailROs to set
     */
    public void setProductDetailROs(List<ProductDetailRO> productDetailROs) {
        this.productDetailROs = productDetailROs;
    }

}
