package com.hackathon.product.entities;

import org.springframework.boot.autoconfigure.domain.EntityScan;

@EntityScan
public class PurchaseDetailEntity {
    
    
    private Long purchaseID;

    private Long userID;

    private Long productID;


    public PurchaseDetailEntity(Long purchaseID, Long userId, Long productId) {

        this.purchaseID = purchaseID;
        this.userID = userId;
        this.productID = productId;
    }

    /**
     * @return Long return the purchaseID
     */
    public Long getPurchaseID() {
        return purchaseID;
    }

    /**
     * @param purchaseID the purchaseID to set
     */
    public void setPurchaseID(Long purchaseID) {
        this.purchaseID = purchaseID;
    }

    /**
     * @return Long return the userID
     */
    public Long getUserID() {
        return userID;
    }

    /**
     * @param userID the userID to set
     */
    public void setUserID(Long userID) {
        this.userID = userID;
    }

    /**
     * @return Long return the productID
     */
    public Long getProductID() {
        return productID;
    }

    /**
     * @param productID the productID to set
     */
    public void setProductID(Long productID) {
        this.productID = productID;
    }

}
