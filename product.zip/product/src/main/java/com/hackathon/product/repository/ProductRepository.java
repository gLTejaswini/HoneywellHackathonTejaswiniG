package com.hackathon.product.repository;

import com.hackathon.product.entities.ProductDetailEntity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<ProductDetailEntity, Long> {

}
