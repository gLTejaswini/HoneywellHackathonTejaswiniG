package com.hackathon.product.service;

import java.util.List;
import java.util.ArrayList;
import java.util.UUID;

import com.hackathon.product.entities.ProductDetailEntity;
import com.hackathon.product.entities.PurchaseDetailEntity;
import com.hackathon.product.entities.UserDetailEntity;
import com.hackathon.product.repository.UserPurchaseRepository;
import com.hackathon.product.repository.UserRepository;
import com.hackathon.product.requestObjects.ProductDetailRO;
import com.hackathon.product.requestObjects.UserPurchaseDetailRO;

import org.hibernate.id.GUIDGenerator;
import org.springframework.beans.factory.annotation.Autowired;

public class ProductPurchaseService {

    @Autowired
    UserPurchaseRepository userPurchaseRepository;

    @Autowired
    UserRepository userRepository;

	public void savePurchaseDetails(UserPurchaseDetailRO userPurchaseDetailRO) {

        UserDetailEntity userDetailEntity = new UserDetailEntity(userPurchaseDetailRO.getUserDetail());
        userRepository.save(userDetailEntity);

        

        List<PurchaseDetailEntity> purchaseDetailEntities = generatePurchaseDetailEntities(Long.valueOf(UUID.randomUUID().toString(), userDetailEntity.getUserId(), userPurchaseDetailRO.getProductDetailROs());

        userPurchaseRepository.saveAll(purchaseDetailEntities);

	}

    private List<PurchaseDetailEntity> generatePurchaseDetailEntities(Long purchaseID, Long userId,
            List<ProductDetailRO> productDetailROs) {
        
            List<PurchaseDetailEntity> purchaseDetailEntities = new ArrayList<PurchaseDetailEntity>();
                
            for(ProductDetailRO productDetailRO: productDetailROs)
            {
                ProductDetailEntity productDetailEntity = new ProductDetailEntity(productDetailRO);
                PurchaseDetailEntity purchaseDetailEntity = new PurchaseDetailEntity(purchaseID, userId, productDetailEntity.getProductId());

                purchaseDetailEntities.add(purchaseDetailEntity);
            }
            
            return purchaseDetailEntities;
    }
    
}
