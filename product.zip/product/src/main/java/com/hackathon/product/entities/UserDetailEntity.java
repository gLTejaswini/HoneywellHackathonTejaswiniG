package com.hackathon.product.entities;

import java.util.UUID;

import javax.persistence.GeneratedValue;

import com.hackathon.product.requestObjects.UserDetailRO;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.annotation.Id;

@EntityScan
public class UserDetailEntity {
    
    
    private @Id @GeneratedValue Long userId;
    private String userName;
    private String userAddress;

    public UserDetailEntity(UserDetailRO userDetail) {

        this.userId = Long.valueOf(UUID.randomUUID().toString());
        this.userName = userDetail.getUserName();
        this.userAddress = userDetail.getUserAddress();
    }
    /**
     * @return @Id @GeneratedValue Long return the userId
     */
    public @Id @GeneratedValue Long getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(@Id @GeneratedValue Long userId) {
        this.userId = userId;
    }

    /**
     * @return String return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return String return the userAddress
     */
    public String getUserAddress() {
        return userAddress;
    }

    /**
     * @param userAddress the userAddress to set
     */
    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

}
