package com.hackathon.product.repository;

import com.hackathon.product.entities.UserDetailEntity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserDetailEntity, Long> {

}