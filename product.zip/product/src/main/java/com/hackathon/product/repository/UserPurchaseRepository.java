package com.hackathon.product.repository;

import com.hackathon.product.entities.PurchaseDetailEntity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserPurchaseRepository extends JpaRepository<PurchaseDetailEntity, Long> {

}
